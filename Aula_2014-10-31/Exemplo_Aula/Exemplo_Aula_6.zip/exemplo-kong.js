console.log("v6");

var game = new Phaser.Game (
  600, 
  400, 
  Phaser.AUTO, 
  "div-jogo",
  {
    preload: MeuPreload,
    create: MeuCreate,
    update: MeuUpdate
  });

var kong;

function MeuPreload ()
{
  kongregateAPI.loadAPI(TerminouDeConectar);
}

function MeuCreate ()
{
  game.input.onDown.add(
    function () 
    {
      console.log("clicou");
      kong.stats.submit("quantos-cliques", 1);
    },
    this
  );
}

function MeuUpdate ()
{
  
}

function TerminouDeConectar () 
{
  kong = kongregateAPI.getAPI();
  console.log(kong.services.getUsername());
}
  










  
  
  
  